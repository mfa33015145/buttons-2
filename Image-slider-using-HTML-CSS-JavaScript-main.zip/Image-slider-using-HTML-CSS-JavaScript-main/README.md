# Animated Imaged Slider HTML CSS & JavaScript 
## Animated Carousel Design

<img src="./image/Image Slider using HTML CSS and JavaScript.png">